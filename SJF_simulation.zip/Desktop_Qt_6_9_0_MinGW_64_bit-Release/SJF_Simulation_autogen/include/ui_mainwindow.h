/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QVBoxLayout *verticalLayoutCentral;
    QStackedWidget *stackedWidget;
    QWidget *page_0;
    QVBoxLayout *verticalLayoutPage0;
    QLabel *titleLabel;
    QLabel *processLabel;
    QLineEdit *process_num;
    QPushButton *processes_continue;
    QWidget *page_1;
    QVBoxLayout *verticalLayoutPage1;
    QLabel *burstTimesLabel;
    QVBoxLayout *processInputLayout;
    QPushButton *simulate_button;
    QWidget *page_2;
    QVBoxLayout *verticalLayoutPage2;
    QLabel *resultsTitle;
    QTableWidget *resultsTable;
    QLabel *averageResultsLabel;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(800, 600);
        MainWindow->setStyleSheet(QString::fromUtf8("\n"
"    QMainWindow {\n"
"        background-color: #f4f6fa;\n"
"    }\n"
"    QLabel {\n"
"        color: #333;\n"
"    }\n"
"    QLineEdit {\n"
"        padding: 8px;\n"
"        font-size: 16px;\n"
"        border: 1px solid #ccc;\n"
"        border-radius: 6px;\n"
"    }\n"
"    QPushButton {\n"
"        background-color: #2b7bb9;\n"
"        color: white;\n"
"        font-size: 16px;\n"
"        border-radius: 6px;\n"
"        padding: 10px;\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #225c8c;\n"
"    }\n"
"   "));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        verticalLayoutCentral = new QVBoxLayout(centralwidget);
        verticalLayoutCentral->setObjectName("verticalLayoutCentral");
        stackedWidget = new QStackedWidget(centralwidget);
        stackedWidget->setObjectName("stackedWidget");
        page_0 = new QWidget();
        page_0->setObjectName("page_0");
        verticalLayoutPage0 = new QVBoxLayout(page_0);
        verticalLayoutPage0->setObjectName("verticalLayoutPage0");
        verticalLayoutPage0->setAlignment(Qt::AlignCenter);
        titleLabel = new QLabel(page_0);
        titleLabel->setObjectName("titleLabel");
        titleLabel->setAlignment(Qt::AlignCenter);
        titleLabel->setStyleSheet(QString::fromUtf8("font-size: 24px; font-weight: bold; margin: 20px;"));

        verticalLayoutPage0->addWidget(titleLabel);

        processLabel = new QLabel(page_0);
        processLabel->setObjectName("processLabel");
        processLabel->setAlignment(Qt::AlignCenter);
        processLabel->setStyleSheet(QString::fromUtf8("font-size: 16px; margin: 10px;"));

        verticalLayoutPage0->addWidget(processLabel);

        process_num = new QLineEdit(page_0);
        process_num->setObjectName("process_num");
        process_num->setMinimumHeight(40);
        process_num->setMaximumWidth(300);

        verticalLayoutPage0->addWidget(process_num);

        processes_continue = new QPushButton(page_0);
        processes_continue->setObjectName("processes_continue");
        processes_continue->setMinimumHeight(40);
        processes_continue->setMaximumWidth(200);

        verticalLayoutPage0->addWidget(processes_continue);

        stackedWidget->addWidget(page_0);
        page_1 = new QWidget();
        page_1->setObjectName("page_1");
        verticalLayoutPage1 = new QVBoxLayout(page_1);
        verticalLayoutPage1->setObjectName("verticalLayoutPage1");
        verticalLayoutPage1->setAlignment(Qt::AlignCenter);
        burstTimesLabel = new QLabel(page_1);
        burstTimesLabel->setObjectName("burstTimesLabel");
        burstTimesLabel->setAlignment(Qt::AlignCenter);
        burstTimesLabel->setStyleSheet(QString::fromUtf8("font-size: 20px; font-weight: bold; margin: 15px;"));

        verticalLayoutPage1->addWidget(burstTimesLabel);

        processInputLayout = new QVBoxLayout();
        processInputLayout->setSpacing(10);
        processInputLayout->setObjectName("processInputLayout");

        verticalLayoutPage1->addLayout(processInputLayout);

        simulate_button = new QPushButton(page_1);
        simulate_button->setObjectName("simulate_button");
        simulate_button->setMinimumHeight(40);
        simulate_button->setMaximumWidth(200);

        verticalLayoutPage1->addWidget(simulate_button);

        stackedWidget->addWidget(page_1);
        page_2 = new QWidget();
        page_2->setObjectName("page_2");
        verticalLayoutPage2 = new QVBoxLayout(page_2);
        verticalLayoutPage2->setObjectName("verticalLayoutPage2");
        verticalLayoutPage2->setAlignment(Qt::AlignCenter);
        resultsTitle = new QLabel(page_2);
        resultsTitle->setObjectName("resultsTitle");
        resultsTitle->setAlignment(Qt::AlignCenter);
        resultsTitle->setStyleSheet(QString::fromUtf8("font-size: 20px; font-weight: bold; margin: 15px;"));

        verticalLayoutPage2->addWidget(resultsTitle);

        resultsTable = new QTableWidget(page_2);
        resultsTable->setObjectName("resultsTable");
        resultsTable->setRowCount(0);
        resultsTable->setColumnCount(4);
        resultsTable->setStyleSheet(QString::fromUtf8("font-size: 14px; margin: 10px;"));

        verticalLayoutPage2->addWidget(resultsTable);

        averageResultsLabel = new QLabel(page_2);
        averageResultsLabel->setObjectName("averageResultsLabel");
        averageResultsLabel->setAlignment(Qt::AlignCenter);
        averageResultsLabel->setStyleSheet(QString::fromUtf8("font-size: 14px; margin-top: 10px;"));

        verticalLayoutPage2->addWidget(averageResultsLabel);

        stackedWidget->addWidget(page_2);

        verticalLayoutCentral->addWidget(stackedWidget);

        MainWindow->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName("statusbar");
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        titleLabel->setText(QCoreApplication::translate("MainWindow", "SJF Simulation", nullptr));
        processLabel->setText(QCoreApplication::translate("MainWindow", "Enter Number of Processes:", nullptr));
        processes_continue->setText(QCoreApplication::translate("MainWindow", "Continue", nullptr));
        burstTimesLabel->setText(QCoreApplication::translate("MainWindow", "Enter Burst Times", nullptr));
        simulate_button->setText(QCoreApplication::translate("MainWindow", "Simulate", nullptr));
        resultsTitle->setText(QCoreApplication::translate("MainWindow", "Simulation Results - SJF", nullptr));
        resultsTable->setHorizontalHeaderLabels(QStringList{
            QCoreApplication::translate("MainWindow", "Process ID", nullptr),
            QCoreApplication::translate("MainWindow", "Burst Time", nullptr),
            QCoreApplication::translate("MainWindow", "Waiting Time", nullptr),
            QCoreApplication::translate("MainWindow", "Turnaround Time", nullptr)});
        averageResultsLabel->setText(QCoreApplication::translate("MainWindow", "Average Waiting Time: 0 | Average Turnaround Time: 0", nullptr));
        (void)MainWindow;
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
